import{l as o,b as r}from"../chunks/CPF_VgrF.js";export{o as load_css,r as start};
