<script>
  export let title = 'KrisPoint';
  export let showUserInfo = true;
  export let showNewReportButton = false;
  export let sidebarCollapsed = false;
  
  // Create event dispatcher
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();
  
  function handleNewReport() {
    dispatch('newReport');
  }
  
  function handleToggleSidebar() {
    dispatch('toggleSidebar');
  }
</script>

<header class="header">
  <div class="header-content">
    <div class="header-left">
      <button class="sidebar-toggle" on:click={handleToggleSidebar} title="Toggle sidebar">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
          <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
        </svg>
      </button>
      <h1>{title}</h1>
    </div>
    <div class="header-actions">
      {#if showNewReportButton}
        <button class="btn btn-primary" on:click={handleNewReport}>
          <span class="btn-icon">+</span>
          New Report
        </button>
      {/if}
      {#if showUserInfo}
        <div class="user-info">
          <div class="avatar">DR</div>
          <div>
            <div class="user-name">Dr. Smith</div>
            <div class="user-role">Radiologist</div>
          </div>
        </div>
      {/if}
    </div>
  </div>
</header>

<style>
  .header {
    background: white;
    padding: 0.75rem 1.5rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  }
  
  .header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  
  .header-left {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  .sidebar-toggle {
    padding: 0.5rem;
    border-radius: 0.375rem;
    background: none;
    border: none;
    cursor: pointer;
    color: #64748b;
    transition: background-color 0.2s;
  }
  
  .sidebar-toggle:hover {
    background: #f1f5f9;
    color: #2563eb;
  }
  
  .header h1 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
    color: #1e293b;
  }
  
  .header-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  .btn {
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    border: none;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    transition: background-color 0.2s;
  }
  
  .btn-primary {
    background: #2563eb;
    color: white;
  }
  
  .btn-primary:hover {
    background: #1d4ed8;
  }
  
  .btn-icon {
    font-size: 1.2rem;
    font-weight: bold;
  }
  
  .user-info {
    display: flex;
    align-items: center;
    gap: 0.75rem;
  }
  
  .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #2563eb;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
  }
  
  .user-name {
    font-weight: 500;
  }
  
  .user-role {
    font-size: 0.875rem;
    color: #64748b;
  }
</style>