<script>
  export let active = false;
</script>

<div class="voice-wave">
  {#each [1, 2, 3, 4, 5] as i}
    <div class="wave-bar {active ? 'active' : ''}" style="--delay: {i * 0.1}s"></div>
  {/each}
</div>

<style>
  .voice-wave {
    display: flex;
    align-items: center;
    gap: 2px;
    height: 20px;
  }
  
  .wave-bar {
    width: 3px;
    background-color: #d1d5db;
    border-radius: 1px;
    height: 5px;
    transition: height 0.3s ease-in-out;
    animation: none;
  }
  
  .wave-bar.active {
    animation: wave 1s infinite;
    animation-delay: var(--delay);
  }
  
  @keyframes wave {
    0%, 100% { height: 5px; }
    50% { height: 15px; background-color: #059669; }
  }
</style>