<script>
  import { page } from '$app/stores';
  
  export let sidebarCollapsed = false;
  
  // Create event dispatcher
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();
  
  function toggleSidebar() {
    dispatch('toggleSidebar');
  }
  
  const menuItems = [
    { id: '', label: 'Home', icon: '🏠' },
    { id: 'reporting', label: 'Reporting', icon: '📝' }, // Add this line
    { id: 'reports', label: 'Reports', icon: '📚' },
    { id: 'templates', label: 'Templates', icon: '📋' },
    { id: 'macros', label: 'Macros', icon: '⚡' },
    { id: 'settings', label: 'Settings', icon: '⚙️' }
  ];
</script>

<div class="sidebar" class:collapsed={sidebarCollapsed}>
  <div class="sidebar-header">
    <div class="logo">
      {#if !sidebarCollapsed}
        <h1>KrisPoint</h1>
      {:else}
        <h1>KP</h1>
      {/if}
    </div>
    <button class="sidebar-toggle" on:click={toggleSidebar} title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
        <path fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
      </svg>
    </button>
  </div>
  
  <nav class="sidebar-nav">
    {#each menuItems as item}
      <a
        href="/{item.id}"
        class:active={$page.url.pathname === `/${item.id}`}
        class="nav-item"
        title={item.label}
      >
        <span class="icon">{item.icon}</span>
        {#if !sidebarCollapsed}
          <span class="label">{item.label}</span>
        {/if}
      </a>
    {/each}
  </nav>
  
  <div class="sidebar-footer">
    <a href="/help" class="nav-item" title="Help & Support">
      <span class="icon">❓</span>
      {#if !sidebarCollapsed}
        <span class="label">Help & Support</span>
      {/if}
    </a>
  </div>
</div>

<style>
  .sidebar {
    width: 250px;
    background: #1e293b;
    color: white;
    padding: 1rem;
    display: flex;
    flex-direction: column;
    transition: width 0.3s ease;
    flex-shrink: 0;
  }
  
  .sidebar.collapsed {
    width: 60px;
  }
  
  .sidebar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 1rem;
    margin-bottom: 1rem;
    border-bottom: 1px solid #334155;
  }
  
  .logo h1 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: bold;
  }
  
  .sidebar-toggle {
    padding: 0.25rem;
    border: none;
    background: none;
    cursor: pointer;
    color: white;
    border-radius: 0.25rem;
    transition: background-color 0.2s;
  }
  
  .sidebar-toggle:hover {
    background: #334155;
  }
  
  .sidebar-nav {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .nav-item {
    display: flex;
    align-items: center;
    padding: 0.75rem;
    border-radius: 0.5rem;
    color: white;
    text-decoration: none;
    transition: background-color 0.2s;
    gap: 0.75rem;
  }
  
  .nav-item:hover {
    background: #334155;
  }
  
  .nav-item.active {
    background: #2563eb;
  }
  
  .icon {
    font-size: 1.2rem;
  }
  
  .sidebar-footer {
    margin-top: auto;
    padding-top: 1rem;
    border-top: 1px solid #334155;
  }
</style>