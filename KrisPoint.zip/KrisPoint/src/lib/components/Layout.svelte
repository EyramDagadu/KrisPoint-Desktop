<!-- src/lib/components/Layout.svelte -->
<script>
  import Header from './Header.svelte';
  import Sidebar from './Sidebar.svelte';
  
  export let pageTitle = 'KrisPoint';
  export let showUserInfo = true;
  export let showNewReportButton = false;
  export let sidebarCollapsed = false;
  
  import { createEventDispatcher } from 'svelte';
  const dispatch = createEventDispatcher();
  
  function handleNewReport() {
    dispatch('newReport');
  }
  
  function handleToggleSidebar() {
    dispatch('toggleSidebar');
  }
</script>

<div class="app-layout">
  <Sidebar 
    {sidebarCollapsed}
    on:toggleSidebar={handleToggleSidebar}
  />
  
  <div class="main-content">
    <Header 
      title={pageTitle}
      {showUserInfo}
      {showNewReportButton}
      {sidebarCollapsed}
      on:newReport={handleNewReport}
      on:toggleSidebar={handleToggleSidebar}
    />
    
    <main class="content-area">
      <slot />
    </main>
  </div>
</div>

<style>
  .app-layout {
    display: flex;
    height: 100vh;
    background: #f8fafc;
    overflow: hidden;
  }
  
  .main-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-width: 0; /* Prevents flex item from overflowing */
    overflow: hidden;
  }
  
  .content-area {
    flex: 1;
    overflow: auto;
    padding: 1.5rem;
    background: #f8fafc;
  }
  
  /* Special styling for reporting page - full height, no padding */
  :global(.content-area:has(.reporting-container)) {
    padding: 0;
    overflow: hidden;
  }
  
  /* Fallback for browsers that don't support :has() */
  :global(.reporting-page) .content-area {
    padding: 0;
    overflow: hidden;
  }
  
  @media (max-width: 768px) {
    .content-area {
      padding: 1rem;
    }
    
    :global(.content-area:has(.reporting-container)),
    :global(.reporting-page) .content-area {
      padding: 0;
    }
  }
</style>