<script>
  import { reportData, uiState } from '$lib/stores/reportStore';
  
  let activeTab = 'macros';
  let searchTerm = '';
  
  const macroCategories = [
    {
      name: 'Normal Findings',
      macros: [
        { name: 'Normal CT Head', text: 'Noncontrast CT of the head demonstrates no intracranial hemorrhage, mass effect, or acute territorial infarction.' },
        { name: 'Normal Chest X-Ray', text: 'The lungs are clear without evidence of focal consolidation, pneumothorax, or pleural effusion.' },
        { name: 'Normal Abdomen CT', text: 'CT of the abdomen and pelvis demonstrates no acute abnormalities.' }
      ]
    },
    {
      name: 'Common Phrases',
      macros: [
        { name: 'Limited Study', text: 'This study is limited by patient body habitus and motion artifact.' },
        { name: 'Clinical Correlation', text: 'Clinical correlation is recommended.' },
        { name: 'No Acute Findings', text: 'No acute findings are identified.' }
      ]
    }
  ];
  
  function insertMacro(macroText) {
    // Get current section from store
    let currentSection;
    const unsubscribe = uiState.subscribe(state => {
      currentSection = state.currentSection;
    });
    unsubscribe();
    
    // Insert macro into current section
    reportData.update(data => ({
      ...data,
      [currentSection]: data[currentSection] + ' ' + macroText
    }));
  }
</script>

<div class="macro-panel">
  <div class="panel-header">
    <h3>Quick Macros</h3>
    <div class="search-box">
      <input 
        type="text" 
        bind:value={searchTerm}
        placeholder="Search macros..." 
        class="search-input"
      />
    </div>
  </div>
  
  <div class="macros-content">
    {#each macroCategories as category}
      <div class="macro-category">
        <h4>{category.name}</h4>
        <div class="macro-list">
          {#each category.macros as macro}
            {#if !searchTerm || macro.name.toLowerCase().includes(searchTerm.toLowerCase()) || macro.text.toLowerCase().includes(searchTerm.toLowerCase())}
              <button 
                class="macro-item" 
                on:click={() => insertMacro(macro.text)}
              >
                <div class="macro-name">{macro.name}</div>
                <div class="macro-preview">{macro.text.slice(0, 60)}...</div>
              </button>
            {/if}
          {/each}
        </div>
      </div>
    {/each}
  </div>
</div>

<style>
  .macro-panel {
    display: flex;
    flex-direction: column;
    height: 100%;
  }
  
  .panel-header {
    padding: 0 0 0.75rem 0;
  }
  
  .panel-header h3 {
    margin: 0 0 0.5rem 0;
    font-size: 0.875rem;
    color: #374151;
  }
  
  .search-input {
    width: 100%;
    padding: 0.375rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    font-size: 0.75rem;
  }
  
  .macros-content {
    flex: 1;
    overflow-y: auto;
  }
  
  .macro-category {
    margin-bottom: 1rem;
  }
  
  .macro-category h4 {
    margin: 0 0 0.5rem 0;
    font-size: 0.75rem;
    color: #6b7280;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  
  .macro-list {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
  }
  
  .macro-item {
    padding: 0.5rem;
    border: 1px solid #e5e7eb;
    border-radius: 0.375rem;
    background: white;
    text-align: left;
    cursor: pointer;
    transition: all 0.2s;
  }
  
  .macro-item:hover {
    background: #eff6ff;
    border-color: #bfdbfe;
  }
  
  .macro-name {
    font-weight: 500;
    color: #1f2937;
    font-size: 0.75rem;
    margin-bottom: 0.25rem;
  }
  
  .macro-preview {
    font-size: 0.6875rem;
    color: #6b7280;
    line-height: 1.3;
  }
</style>