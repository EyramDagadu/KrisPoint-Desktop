<!-- src/lib/components/reporting/ReportWorkspace.svelte -->
<script>
  import { onMount } from 'svelte';
  import { 
    reportData, 
    patientData, 
    uiState, 
    reportActions, 
    uiActions,
    hasCompletePatientData
  } from '../../stores/reportStore.js';
  
  import PatientBanner from './PatientBanner.svelte';
  import PatientHeader from './PatientHeader.svelte';
  import ReportEditor from './ReportEditor.svelte';
  import ToolsPanel from './ToolsPanel.svelte';
  import FooterBar from './FooterBar.svelte';
  import VoiceControl from './VoiceControl.svelte';

  let currentSection = $uiState.currentSection || 'findings';
  let isSaved = true;
  let lastSaveTime = null;

  // Reactive statements
  $: currentSection = $uiState.currentSection;

  onMount(() => {
    // Load any saved report on mount
    reportActions.loadFromStorage();
    
    // Set up auto-save interval
    const autoSaveInterval = setInterval(() => {
      if (!isSaved) {
        saveReport();
      }
    }, 30000);

    // If no complete patient data, show modal
    if (!$hasCompletePatientData) {
      uiActions.showPatientModal();
    }

    return () => {
      clearInterval(autoSaveInterval);
    };
  });

  function handleSectionChange(section) {
    uiActions.setCurrentSection(section);
  }

  function handleContentChange(event) {
    const { section, content } = event.detail;
    reportActions.updateSection(section, content);
    isSaved = false;
  }

  function saveReport() {
    reportActions.saveToStorage();
    isSaved = true;
    lastSaveTime = new Date();
  }

  function handleNewReport() {
    // Clear everything and start fresh
    reportActions.clearReport();
    uiActions.showPatientModal();
    isSaved = true;
  }

  function handlePatientStartReport() {
    // Close modal and proceed to reporting
    uiActions.hidePatientModal();
    // Set focus on first section
    uiActions.setCurrentSection('findings');
  }

  function handlePatientCancel() {
    uiActions.hidePatientModal();
    // If no patient data exists, we stay in empty state
  }

  function handleEditPatient() {
    uiActions.showPatientModal();
  }

  function handleKeydown(event) {
    // Alt + number keys for section navigation
    if (event.altKey && event.key >= '1' && event.key <= '4') {
      event.preventDefault();
      const sections = ['comparison', 'technique', 'findings', 'impression'];
      const sectionIndex = parseInt(event.key) - 1;
      if (sections[sectionIndex]) {
        handleSectionChange(sections[sectionIndex]);
      }
    }
    
    // Ctrl/Cmd + S to save
    if ((event.ctrlKey || event.metaKey) && event.key === 's') {
      event.preventDefault();
      saveReport();
    }
    
    // Ctrl/Cmd + N for new report
    if ((event.ctrlKey || event.metaKey) && event.key === 'n') {
      event.preventDefault();
      handleNewReport();
    }
    
    // Ctrl/Cmd + E to edit patient
    if ((event.ctrlKey || event.metaKey) && event.key === 'e') {
      event.preventDefault();
      if ($hasCompletePatientData) {
        handleEditPatient();
      }
    }
  }
</script>

<svelte:window on:keydown={handleKeydown} />

<div class="report-workspace">
  {#if $hasCompletePatientData}
    <!-- Patient Banner - compact header -->
    <header class="workspace-header">
      <PatientBanner 
        patient={$patientData} 
        on:editPatient={handleEditPatient}
        on:newReport={handleNewReport}
      />
    </header>
    
    <!-- Main Workspace -->
    <main class="workspace-main">
      <aside class="tools-panel">
        <ToolsPanel 
          currentSection={currentSection} 
          on:macroInsert={handleContentChange} 
        />
      </aside>

      <section class="editor-panel">
        <ReportEditor 
          section={currentSection}
          content={$reportData[currentSection] || ''}
          on:contentChange={handleContentChange}
          on:save={saveReport}
        />
      </section>

      <aside class="voice-panel">
        <VoiceControl />
      </aside>
    </main>

    <!-- Footer -->
    <footer class="workspace-footer">
      <FooterBar 
        {isSaved} 
        {lastSaveTime} 
        wordCount={($reportData[currentSection] || '').split(/\s+/).filter(w => w.length > 0).length} 
        on:save={saveReport}
        on:newReport={handleNewReport}
      />
    </footer>
  {:else}
    <!-- Empty State - when no patient data -->
    <div class="empty-state">
      <div class="empty-content">
        <div class="empty-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2H6C4.9 2 4 2.9 4 4V20C4 21.1 4.89 22 5.99 22H18C19.1 22 20 21.1 20 20V8L14 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 2V8H20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 13H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M16 17H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M10 9H9H8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </div>
        <h2>Welcome to Radiology Reporting</h2>
        <p>Enter patient information to begin your radiology report</p>
        <button class="btn btn-primary btn-large" on:click={() => uiActions.showPatientModal()}>
          <span class="btn-icon">📋</span>
          Start New Report
        </button>
      </div>
    </div>
  {/if}

  <!-- Patient Information Modal -->
  {#if $uiState.showPatientModal}
    <div class="modal-backdrop" on:click={handlePatientCancel}>
      <div class="modal-container" on:click|stopPropagation>
        <div class="modal-header">
          <h2>
            {$hasCompletePatientData ? 'Edit Patient Information' : 'New Radiology Report'}
          </h2>
          <button class="modal-close" on:click={handlePatientCancel} aria-label="Close">
            ×
          </button>
        </div>
        <div class="modal-content">
          <PatientHeader 
            on:startReport={handlePatientStartReport}
            on:cancel={handlePatientCancel}
          />
        </div>
      </div>
    </div>
  {/if}
</div>

<style>
  .report-workspace {
    display: flex;
    flex-direction: column;
    height: 100vh;
    background-color: #f8fafc;
    position: relative;
  }

  .workspace-header {
    background: white;
    border-bottom: 1px solid #e2e8f0;
    flex-shrink: 0;
  }

  .workspace-main {
    flex: 1;
    display: grid;
    grid-template-columns: 300px 1fr 280px;
    gap: 0;
    overflow: hidden;
    min-height: 0;
  }

  .tools-panel {
    background: white;
    border-right: 1px solid #e2e8f0;
    overflow-y: auto;
  }

  .editor-panel {
    background: white;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border-right: 1px solid #e2e8f0;
  }

  .voice-panel {
    background: #f8fafc;
    overflow-y: auto;
  }

  .workspace-footer {
    background: white;
    border-top: 1px solid #e2e8f0;
    flex-shrink: 0;
  }

  /* Empty State Styles */
  .empty-state {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    text-align: center;
  }

  .empty-content {
    max-width: 400px;
    padding: 3rem 2rem;
    animation: fadeInUp 0.6s ease-out;
  }

  .empty-icon {
    color: rgba(255, 255, 255, 0.8);
    margin-bottom: 1.5rem;
    display: flex;
    justify-content: center;
  }

  .empty-content h2 {
    margin: 0 0 1rem 0;
    font-size: 2rem;
    font-weight: 600;
    color: white;
  }

  .empty-content p {
    margin: 0 0 2rem 0;
    font-size: 1.125rem;
    color: rgba(255, 255, 255, 0.9);
    line-height: 1.6;
  }

  /* Modal Styles */
  .modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.75);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
    padding: 1rem;
    animation: fadeIn 0.2s ease-out;
  }

  .modal-container {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    max-width: 900px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    animation: slideInScale 0.3s ease-out;
  }

  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 2rem 2rem 1rem;
    border-bottom: 1px solid #e2e8f0;
    position: sticky;
    top: 0;
    background: white;
    z-index: 10;
  }

  .modal-header h2 {
    margin: 0;
    color: #1e293b;
    font-size: 1.75rem;
    font-weight: 700;
  }

  .modal-close {
    background: none;
    border: none;
    font-size: 1.75rem;
    cursor: pointer;
    color: #64748b;
    padding: 0;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.5rem;
    transition: all 0.2s ease-in-out;
  }

  .modal-close:hover {
    color: #334155;
    background: #f1f5f9;
    transform: scale(1.05);
  }

  .modal-content {
    padding: 0 2rem 2rem;
  }

  /* Button Styles */
  .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    border: none;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.875rem;
    text-decoration: none;
    transition: all 0.2s ease-in-out;
    gap: 0.5rem;
  }

  .btn-primary {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    color: white;
    box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3);
  }

  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 15px -3px rgba(59, 130, 246, 0.4);
  }

  .btn-primary:active {
    transform: translateY(0);
  }

  .btn-large {
    padding: 1rem 2rem;
    font-size: 1rem;
    border-radius: 0.75rem;
  }

  .btn-icon {
    font-size: 1.25em;
  }

  /* Animations */
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes slideInScale {
    from {
      opacity: 0;
      transform: translateY(-20px) scale(0.95);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  /* Responsive Design */
  @media (max-width: 1200px) {
    .workspace-main {
      grid-template-columns: 250px 1fr 220px;
    }
  }

  @media (max-width: 1024px) {
    .workspace-main {
      grid-template-columns: 200px 1fr;
    }
    
    .voice-panel {
      display: none;
    }
  }

  @media (max-width: 768px) {
    .workspace-main {
      grid-template-columns: 1fr;
      grid-template-rows: auto 1fr;
    }
    
    .tools-panel {
      border-right: none;
      border-bottom: 1px solid #e2e8f0;
      max-height: 200px;
    }
    
    .editor-panel {
      border-right: none;
    }
    
    .modal-container {
      margin: 0.5rem;
      max-height: 95vh;
    }
    
    .modal-header {
      padding: 1.5rem 1.5rem 1rem;
    }
    
    .modal-header h2 {
      font-size: 1.5rem;
    }
    
    .modal-content {
      padding: 0 1.5rem 1.5rem;
    }
    
    .empty-content {
      padding: 2rem 1.5rem;
    }
    
    .empty-content h2 {
      font-size: 1.75rem;
    }
  }

  @media (max-width: 480px) {
    .modal-backdrop {
      padding: 0.5rem;
    }
    
    .btn-large {
      width: 100%;
      padding: 1rem;
    }
  }
</style>