<!-- src/lib/components/reporting/ToolsPanel.svelte -->
<script>
  import { uiState, reportData, reportActions } from '$lib/stores/reportStore';
  
  export let currentSection = 'findings';
  
  // Radiology-specific macros organized by section
  const macrosBySection = {
    comparison: [
      { label: 'Compared to prior', text: 'Compared to prior {study} from {date}.' },
      { label: 'No prior studies', text: 'No prior studies available for comparison.' }
    ],
    technique: [
      { label: 'CT Technique', text: 'Axial images were obtained through the {region} without intravenous contrast.' },
      { label: 'MRI Technique', text: 'Multiplanar, multisequence MRI images were obtained through the {region}.' }
    ],
    findings: [
      { label: 'Normal Lungs', text: 'Lungs: Clear without focal consolidation, nodule, or effusion.' },
      { label: 'Normal Heart', text: 'Heart: Normal in size and configuration. No pericardial effusion.' },
      { label: 'Normal Bones', text: 'Bones: No acute fracture or destructive lesion identified.' }
    ],
    impression: [
      { label: 'No Acute Findings', text: 'No acute cardiopulmonary process.' },
      { label: 'Clinical Correlation', text: 'Clinical correlation is recommended.' },
      { label: 'Follow-up', text: 'Follow-up as clinically indicated.' }
    ]
  };
  
  function insertMacro(macroText) {
    // Replace placeholders with appropriate values
    let text = macroText;
    text = text.replace('{study}', $reportData.modality || 'study');
    text = text.replace('{date}', new Date().toLocaleDateString());
    text = text.replace('{region}', $reportData.examSubtype || 'region');
    
    // Insert the macro
    reportActions.updateSection(currentSection, 
      ($reportData[currentSection] || '') + 
      ($reportData[currentSection] ? '\n\n' : '') + 
      text
    );
  }
</script>

<aside class="tools-panel">
  <div class="panel-section">
    <h3>Quick Macros</h3>
    <div class="macros-list">
      {#each macrosBySection[currentSection] as macro}
        <button 
          class="macro-btn" 
          on:click={() => insertMacro(macro.text)}
          title="{macro.text}"
        >
          {macro.label}
        </button>
      {/each}
    </div>
  </div>
  
  <div class="panel-section">
    <h3>Common Phrases</h3>
    <div class="phrases-list">
      <button class="phrase-btn" on:click={() => insertMacro('No significant change.')}>
        No significant change
      </button>
      <button class="phrase-btn" on:click={() => insertMacro('Stable appearance.')}>
        Stable appearance
      </button>
      <button class="phrase-btn" on:click={() => insertMacro('Findings are nonspecific.')}>
        Nonspecific findings
      </button>
    </div>
  </div>
</aside>

<style>
  .tools-panel {
    padding: 1rem;
    overflow-y: auto;
  }
  
  .panel-section {
    margin-bottom: 1.5rem;
  }
  
  .panel-section h3 {
    margin: 0 0 0.75rem 0;
    font-size: 0.9rem;
    color: #2c3e50;
    font-weight: 600;
    border-bottom: 1px solid #e9ecef;
    padding-bottom: 0.5rem;
  }
  
  .macros-list, .phrases-list {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .macro-btn, .phrase-btn {
    padding: 0.5rem;
    border: 1px solid #e9ecef;
    border-radius: 0.375rem;
    background: white;
    text-align: left;
    cursor: pointer;
    font-size: 0.8rem;
    transition: all 0.2s;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  .macro-btn:hover, .phrase-btn:hover {
    background: #e3f2fd;
    border-color: #bbdefb;
  }
  
  .macro-btn {
    font-weight: 500;
  }
  
  .phrase-btn {
    font-style: italic;
    color: #546e7a;
  }
</style>