<!-- src/lib/components/reporting/SectionTabs.svelte -->
<script>
  import { uiState, reportData } from '$lib/stores/reportStore';
  
  const sections = [
    { id: 'comparison', label: 'Comparison', icon: '📊', shortcut: 'Alt+1' },
    { id: 'technique', label: 'Technique', icon: '⚙️', shortcut: 'Alt+2' },
    { id: 'findings', label: 'Findings', icon: '🔍', shortcut: 'Alt+3' },
    { id: 'impression', label: 'Impression', icon: '💡', shortcut: 'Alt+4' }
  ];
  
  function selectSection(sectionId) {
    $uiState.currentSection = sectionId;
  }
  
  function hasContent(sectionId) {
    return $reportData[sectionId] && $reportData[sectionId].trim().length > 0;
  }
</script>

<div class="section-tabs">
  {#each sections as section}
    <button
      class="tab {($uiState.currentSection === section.id) ? 'active' : ''} {hasContent(section.id) ? 'has-content' : ''}"
      on:click={() => selectSection(section.id)}
      title="{section.label} ({section.shortcut})"
    >
      <span class="tab-icon">{section.icon}</span>
      <span class="tab-label">{section.label}</span>
      {#if hasContent(section.id)}
        <span class="content-indicator"></span>
      {/if}
    </button>
  {/each}
</div>

<style>
  .section-tabs {
    display: flex;
    background: #34495e;
    border-bottom: 1px solid #2c3e50;
  }
  
  .tab {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.6rem 1rem;
    border: none;
    background: transparent;
    color: #ecf0f1;
    cursor: pointer;
    position: relative;
    transition: all 0.2s ease;
    font-size: 0.85rem;
    border-right: 1px solid #2c3e50;
  }
  
  .tab:hover {
    background: #3c546b;
  }
  
  .tab.active {
    background: #2c3e50;
    color: white;
    font-weight: 500;
  }
  
  .tab.active::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: #3498db;
  }
  
  .tab.has-content .content-indicator {
    display: block;
  }
  
  .content-indicator {
    display: none;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #3498db;
    margin-left: 0.3rem;
  }
  
  .tab-icon {
    font-size: 1rem;
  }
</style>