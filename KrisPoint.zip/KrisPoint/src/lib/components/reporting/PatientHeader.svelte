<!-- src/lib/components/reporting/PatientHeader.svelte -->
<script>
  import { createEventDispatcher } from 'svelte';
  import { patientData, patientActions } from '../../stores/reportStore.js';
  
  const dispatch = createEventDispatcher();

  let customModality = '';
  let customRegion = '';
  let showCustomModal = false;
  let validationErrors = [];

  const examTypes = [
    { value: '', label: 'Select modality' },
    { value: 'ct', label: 'CT' },
    { value: 'mri', label: 'MRI' },
    { value: 'xray', label: 'X-Ray' },
    { value: 'us', label: 'Ultrasound' },
    { value: 'mg', label: 'Mammography' },
    { value: 'fl', label: 'Fluoroscopy' },
    { value: 'nm', label: 'Nuclear Medicine' },
    { value: 'custom', label: 'Custom...' }
  ];

  const examSubtypes = {
    '': [{ value: '', label: 'Select body region' }],
    'ct': [
      { value: '', label: 'Select body region' },
      { value: 'head', label: 'Head' },
      { value: 'neck', label: 'Neck' },
      { value: 'chest', label: 'Chest' },
      { value: 'abdomen', label: 'Abdomen' },
      { value: 'spine', label: 'Spine' },
      { value: 'angio', label: 'Angio' },
      { value: 'cardiac', label: 'Cardiac' },
      { value: 'extremity', label: 'Extremity' },
      { value: 'custom', label: 'Custom...' }
    ],
    'mri': [
      { value: '', label: 'Select body region' },
      { value: 'brain', label: 'Brain' },
      { value: 'spine', label: 'Spine' },
      { value: 'msk', label: 'MSK' },
      { value: 'body', label: 'Body' },
      { value: 'breast', label: 'Breast' },
      { value: 'cardiac', label: 'Cardiac' },
      { value: 'custom', label: 'Custom...' }
    ],
    'xray': [
      { value: '', label: 'Select body region' },
      { value: 'chest', label: 'Chest' },
      { value: 'abdominal', label: 'Abdominal' },
      { value: 'extremity', label: 'Extremity' },
      { value: 'spine', label: 'Spine' },
      { value: 'custom', label: 'Custom...' }
    ],
    'us': [
      { value: '', label: 'Select body region' },
      { value: 'abdominal', label: 'Abdominal' },
      { value: 'pelvic', label: 'Pelvic' },
      { value: 'vascular', label: 'Vascular' },
      { value: 'small', label: 'Small Parts' },
      { value: 'custom', label: 'Custom...' }
    ],
    'mg': [
      { value: '', label: 'Select type' },
      { value: 'screening', label: 'Screening' },
      { value: 'diagnostic', label: 'Diagnostic' },
      { value: 'custom', label: 'Custom...' }
    ],
    'fl': [
      { value: '', label: 'Select procedure' },
      { value: 'gi', label: 'GI Series' },
      { value: 'gu', label: 'GU Studies' },
      { value: 'custom', label: 'Custom...' }
    ],
    'nm': [
      { value: '', label: 'Select study' },
      { value: 'bone', label: 'Bone Scan' },
      { value: 'cardiac', label: 'Cardiac' },
      { value: 'custom', label: 'Custom...' }
    ],
    'custom': [
      { value: '', label: 'Select body region' },
      { value: 'custom', label: 'Custom...' }
    ]
  };

  $: currentSubtypes = examSubtypes[$patientData.examType] || examSubtypes[''];
  
  // Reset examSubtype if it's no longer valid for the current examType
  $: if ($patientData.examType && $patientData.examSubtype) {
    const validSubtypes = currentSubtypes.map(st => st.value);
    if (!validSubtypes.includes($patientData.examSubtype)) {
      patientActions.updateField('examSubtype', '');
    }
  }

  function handleExamTypeChange(e) {
    const newType = e.target.value;
    patientActions.setExamType(newType);
    
    if (newType === 'custom') {
      showCustomModal = true;
    }
  }

  function handleExamSubtypeChange(e) {
    const newSubtype = e.target.value;
    patientActions.setExamSubtype(newSubtype);
    
    if (newSubtype === 'custom') {
      showCustomModal = true;
    }
  }

  function handleFieldChange(field, value) {
    patientActions.updateField(field, value);
    // Clear validation errors when user types
    if (validationErrors.length > 0) {
      validateForm();
    }
  }

  function saveCustomSelections() {
    if (customModality.trim() && $patientData.examType === 'custom') {
      // Set custom modality as the examType value
      patientActions.updateField('examType', customModality.trim());
    }
    
    if (customRegion.trim() && $patientData.examSubtype === 'custom') {
      // Set custom region as the examSubtype value
      patientActions.updateField('examSubtype', customRegion.trim());
    }
    
    showCustomModal = false;
    customModality = '';
    customRegion = '';
  }

  function validateForm() {
    const validation = patientActions.validateRequiredFields();
    validationErrors = validation.errors;
    return validation.isValid;
  }

  function handleStartReport() {
    if (validateForm()) {
      dispatch('startReport');
    }
  }

  function handleCancel() {
    dispatch('cancel');
  }
</script>

<div class="patient-header">
  <div class="patient-form">
    <div class="form-group">
      <label for="patientName">Patient Name *</label>
      <input 
        type="text" 
        id="patientName" 
        value={$patientData.name}
        on:input={(e) => handleFieldChange('name', e.target.value)}
        placeholder="Enter patient name"
        class:error={validationErrors.some(e => e.includes('name'))}
      >
    </div>
    
    <div class="form-group">
      <label for="patientAge">Age</label>
      <input 
        type="number" 
        id="patientAge" 
        value={$patientData.age}
        on:input={(e) => handleFieldChange('age', e.target.value)}
        placeholder="Age"
        min="0" 
        max="150"
      >
    </div>
    
    <div class="form-group">
      <label for="examType">Modality *</label>
      <select 
        id="examType" 
        value={$patientData.examType} 
        on:change={handleExamTypeChange}
        class:error={validationErrors.some(e => e.includes('modality'))}
      >
        {#each examTypes as type}
          <option value={type.value}>{type.label}</option>
        {/each}
      </select>
    </div>
    
    <div class="form-group">
      <label for="examSubtype">Body Region *</label>
      <select 
        id="examSubtype" 
        value={$patientData.examSubtype} 
        on:change={handleExamSubtypeChange}
        disabled={!$patientData.examType}
        class:error={validationErrors.some(e => e.includes('region'))}
      >
        {#each currentSubtypes as subtype}
          <option value={subtype.value}>{subtype.label}</option>
        {/each}
      </select>
    </div>
    
    <div class="form-group indication-group">
      <label for="indication">Clinical Indication</label>
      <input 
        type="text" 
        id="indication" 
        value={$patientData.indication}
        on:input={(e) => handleFieldChange('indication', e.target.value)}
        placeholder="Clinical indication or reason for exam"
      >
    </div>
  </div>

  {#if validationErrors.length > 0}
    <div class="validation-errors">
      <ul>
        {#each validationErrors as error}
          <li>{error}</li>
        {/each}
      </ul>
    </div>
  {/if}

  <div class="form-actions">
    <button class="btn btn-secondary" on:click={handleCancel}>
      Cancel
    </button>
    <button class="btn btn-primary" on:click={handleStartReport}>
      Start Report
    </button>
  </div>
</div>

{#if showCustomModal}
<div class="modal-backdrop" on:click={() => showCustomModal = false}>
  <div class="modal" on:click|stopPropagation>
    <div class="modal-header">
      <h3>Custom Entry</h3>
      <button class="modal-close" on:click={() => showCustomModal = false}>×</button>
    </div>
    
    <div class="modal-body">
      {#if $patientData.examType === 'custom'}
      <div class="form-group">
        <label for="customModality">Custom Modality</label>
        <input 
          id="customModality" 
          type="text" 
          bind:value={customModality} 
          placeholder="Enter custom modality"
          autofocus
        >
      </div>
      {/if}
      
      {#if $patientData.examSubtype === 'custom'}
      <div class="form-group">
        <label for="customRegion">Custom Body Region</label>
        <input 
          id="customRegion" 
          type="text" 
          bind:value={customRegion} 
          placeholder="Enter custom body region"
          autofocus={$patientData.examType !== 'custom'}
        >
      </div>
      {/if}
    </div>
    
    <div class="modal-actions">
      <button class="btn btn-secondary" on:click={() => showCustomModal = false}>
        Cancel
      </button>
      <button class="btn btn-primary" on:click={saveCustomSelections}>
        Save
      </button>
    </div>
  </div>
</div>
{/if}

<style>
  .patient-header {
    background: white;
    padding: 1.5rem;
    border-radius: 0.75rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  }
  
  .patient-form {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
  }
  
  .indication-group {
    grid-column: span 2;
  }
  
  .form-group {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
  }
  
  .form-group label {
    font-weight: 600;
    font-size: 0.875rem;
    color: #374151;
  }
  
  .form-group input, 
  .form-group select {
    padding: 0.5rem;
    border: 2px solid #d1d5db;
    border-radius: 0.375rem;
    font-size: 0.875rem;
    font-family: inherit;
    background: white;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  }

  .form-group input:focus,
  .form-group select:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
  }

  .form-group input:disabled,
  .form-group select:disabled {
    background: #f9fafb;
    color: #9ca3af;
    cursor: not-allowed;
  }

  .form-group input.error,
  .form-group select.error {
    border-color: #ef4444;
    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
  }

  .validation-errors {
    background: #fef2f2;
    border: 1px solid #fecaca;
    border-radius: 0.375rem;
    padding: 0.75rem;
    margin-bottom: 1rem;
  }

  .validation-errors ul {
    margin: 0;
    padding-left: 1.25rem;
    color: #dc2626;
    font-size: 0.875rem;
  }

  .validation-errors li {
    margin-bottom: 0.25rem;
  }

  .form-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
    padding-top: 1rem;
    border-top: 1px solid #e5e7eb;
  }
  
  .btn {
    padding: 0.5rem 1.5rem;
    border-radius: 0.375rem;
    border: none;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.875rem;
    transition: all 0.15s ease-in-out;
    min-width: 120px;
  }
  
  .btn-primary {
    background: #3b82f6;
    color: white;
  }
  
  .btn-primary:hover:not(:disabled) {
    background: #2563eb;
    transform: translateY(-1px);
    box-shadow: 0 4px 6px rgba(59, 130, 246, 0.25);
  }
  
  .btn-primary:active {
    transform: translateY(0);
  }
  
  .btn-secondary {
    background: #6b7280;
    color: white;
  }
  
  .btn-secondary:hover:not(:disabled) {
    background: #4b5563;
  }

  .btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  .modal-backdrop {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    animation: fadeIn 0.15s ease-out;
  }
  
  .modal {
    background: white;
    border-radius: 0.75rem;
    min-width: 400px;
    max-width: 500px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    animation: slideIn 0.15s ease-out;
  }

  .modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid #e5e7eb;
  }

  .modal-header h3 {
    margin: 0;
    font-size: 1.25rem;
    font-weight: 600;
    color: #111827;
  }

  .modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #6b7280;
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 0.375rem;
    transition: background-color 0.15s ease-in-out;
  }

  .modal-close:hover {
    background: #f3f4f6;
    color: #374151;
  }

  .modal-body {
    padding: 1.5rem;
  }
  
  .modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
    padding: 1rem 1.5rem;
    border-top: 1px solid #e5e7eb;
    background: #f9fafb;
    border-radius: 0 0 0.75rem 0.75rem;
  }

  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }

  @keyframes slideIn {
    from { 
      opacity: 0;
      transform: translateY(-20px) scale(0.95);
    }
    to { 
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  @media (max-width: 1024px) {
    .indication-group {
      grid-column: span 1;
    }
  }
  
  @media (max-width: 768px) {
    .patient-form {
      grid-template-columns: 1fr;
    }
    
    .indication-group {
      grid-column: span 1;
    }
    
    .modal {
      width: 90%;
      max-width: 400px;
      margin: 1rem;
    }

    .form-actions {
      flex-direction: column-reverse;
    }

    .btn {
      width: 100%;
    }
  }