<!-- MacroManager.svelte - Fixed integration with corrected macroStore -->
<script>
  import { onMount } from 'svelte';
  import { macroStore, voiceCommandService } from '$lib/stores/macroStore.js';
  
  let macros = [];
  let selectedCategory = 'All';
  let showAddForm = false;
  let editingMacro = null;
  let searchTerm = '';
  let isTestingVoice = false;
  let lastVoiceTest = '';
  
  // Subscribe to macro store
  const unsubscribe = macroStore.subscribe(value => {
    macros = value;
  });
  
  // Form fields
  let newMacro = {
    id: '',
    name: '',
    voiceCommand: '',
    content: '',
    category: 'General',
    variables: []
  };
  
  // Categories for organization
  const categories = [
    'All', 'General', 'Chest', 'Neuro', 'Abdomen', 'Pelvis', 
    'MSK', 'Cardiac', 'Vascular', 'Pediatric', 'Emergency', 'Custom'
  ];
  
  // Common variable placeholders
  const availableVariables = [
    { name: 'DATE', description: 'Current date' },
    { name: 'TIME', description: 'Current time' },
    { name: 'PHYSICIAN', description: 'Physician name' },
    { name: 'PATIENT_NAME', description: 'Patient name' },
    { name: 'AGE', description: 'Patient age' },
    { name: 'EXAM_TYPE', description: 'Type of examination' },
    { name: 'INDICATION', description: 'Clinical indication' }
  ];
  
  onMount(() => {
    // Initialize macro store - this loads defaults and custom macros
    macroStore.init();
  });
  
  function getFilteredMacros() {
    let filtered = macros;
    
    // Filter by category
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(macro => macro.category === selectedCategory);
    }
    
    // Filter by search term
    if (searchTerm.trim()) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(macro => 
        macro.name.toLowerCase().includes(search) ||
        macro.voiceCommand.toLowerCase().includes(search) ||
        macro.content.toLowerCase().includes(search)
      );
    }
    
    return filtered.sort((a, b) => a.name.localeCompare(b.name));
  }
  
  function startAddMacro() {
    resetForm();
    showAddForm = true;
    editingMacro = null;
  }
  
  function startEditMacro(macro) {
    newMacro = { ...macro };
    showAddForm = true;
    editingMacro = macro;
  }
  
  function resetForm() {
    newMacro = {
      id: '',
      name: '',
      voiceCommand: '',
      content: '',
      category: 'General',
      variables: []
    };
    showAddForm = false;
    editingMacro = null;
  }
  
  function saveMacro() {
    // Validation
    if (!newMacro.name.trim() || !newMacro.voiceCommand.trim() || !newMacro.content.trim()) {
      alert('Please fill in all required fields (name, voice command, and content).');
      return;
    }
    
    // Check for duplicate voice commands
    const existingMacro = macros.find(m => 
      m.voiceCommand.toLowerCase() === newMacro.voiceCommand.toLowerCase() && 
      m.id !== newMacro.id
    );
    
    if (existingMacro) {
      alert(`Voice command "${newMacro.voiceCommand}" is already used by macro "${existingMacro.name}". Please choose a different voice command.`);
      return;
    }
    
    try {
      if (editingMacro) {
        macroStore.updateMacro(newMacro.id, newMacro);
      } else {
        macroStore.addMacro(newMacro);
      }
      
      resetForm();
      alert(editingMacro ? 'Macro updated successfully!' : 'Macro created successfully!');
    } catch (error) {
      alert('Error saving macro: ' + error.message);
    }
  }
  
  function deleteMacro(macro) {
    if (confirm(`Are you sure you want to delete the macro "${macro.name}"?`)) {
      const success = macroStore.deleteMacro(macro.id);
      if (success) {
        alert('Macro deleted successfully!');
      } else {
        alert('Cannot delete default macros.');
      }
    }
  }
  
  function duplicateMacro(macro) {
    const duplicate = {
      ...macro,
      name: macro.name + ' (Copy)',
      voiceCommand: macro.voiceCommand + ' copy'
    };
    
    try {
      macroStore.addMacro(duplicate);
      alert('Macro duplicated successfully!');
    } catch (error) {
      alert('Error duplicating macro: ' + error.message);
    }
  }
  
  function testVoiceCommand() {
    if (!newMacro.voiceCommand.trim()) {
      alert('Please enter a voice command first.');
      return;
    }
    
    isTestingVoice = true;
    lastVoiceTest = '';
    
    // Start voice recognition for testing
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      
      recognition.onstart = function() {
        lastVoiceTest = 'Listening... Say: "' + newMacro.voiceCommand + '"';
      };
      
      recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript.toLowerCase();
        const targetCommand = newMacro.voiceCommand.toLowerCase();
        
        if (transcript.includes(targetCommand) || targetCommand.includes(transcript)) {
          lastVoiceTest = '✅ Voice command recognized: "' + transcript + '"';
        } else {
          lastVoiceTest = '❌ Voice command not recognized. You said: "' + transcript + '"';
        }
        
        isTestingVoice = false;
      };
      
      recognition.onerror = function() {
        lastVoiceTest = '❌ Voice recognition error. Please try again.';
        isTestingVoice = false;
      };
      
      recognition.onend = function() {
        if (isTestingVoice) {
          lastVoiceTest = '❌ No voice input detected. Please try again.';
          isTestingVoice = false;
        }
      };
      
      recognition.start();
      
      // Auto-stop after 5 seconds
      setTimeout(() => {
        if (isTestingVoice) {
          recognition.stop();
        }
      }, 5000);
      
    } else {
      alert('Voice recognition not supported in this browser.');
    }
  }
  
  function insertVariable(variable) {
    const placeholder = `[${variable.name}]`;
    newMacro.content += placeholder;
  }
  
  function exportMacros() {
    const exportData = macroStore.exportMacros();
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(exportData);
    
    const exportFileDefaultName = 'krispoint_macros_' + new Date().toISOString().slice(0,10) + '.json';
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }
  
  function importMacros(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
      try {
        const importedCount = macroStore.importMacros(e.target.result);
        alert(`Successfully imported ${importedCount} macros!`);
      } catch (error) {
        alert('Error importing macros: ' + error.message);
      }
    };
    
    reader.readAsText(file);
    event.target.value = '';
  }
</script>

<div class="macro-manager">
  <div class="macro-header">
    <h1>Voice Macro Management</h1>
    <p>Create and manage voice-activated macros for faster reporting</p>
  </div>
  
  <div class="macro-controls">
    <div class="control-group">
      <button class="btn btn-primary" on:click={startAddMacro}>
        ➕ Add New Macro
      </button>
      
      <button class="btn btn-secondary" on:click={exportMacros}>
        📤 Export All
      </button>
      
      <label class="btn btn-secondary">
        📥 Import
        <input type="file" accept=".json" on:change={importMacros} style="display: none;">
      </label>
    </div>
    
    <div class="control-group">
      <input 
        type="text" 
        placeholder="Search macros..." 
        bind:value={searchTerm}
        class="search-input"
      >
      
      <select bind:value={selectedCategory} class="category-select">
        {#each categories as category}
          <option value={category}>{category}</option>
        {/each}
      </select>
    </div>
  </div>
  
  {#if showAddForm}
    <div class="macro-form-overlay">
      <div class="macro-form">
        <div class="form-header">
          <h2>{editingMacro ? 'Edit Macro' : 'Add New Macro'}</h2>
          <button class="btn-close" on:click={resetForm}>✕</button>
        </div>
        
        <div class="form-grid">
          <div class="form-group">
            <label for="macro-name">Macro Name *</label>
            <input 
              type="text" 
              id="macro-name"
              bind:value={newMacro.name}
              placeholder="e.g., Normal Chest X-ray"
              required
            >
          </div>
          
          <div class="form-group">
            <label for="voice-command">Voice Command *</label>
            <div class="voice-input-group">
              <input 
                type="text" 
                id="voice-command"
                bind:value={newMacro.voiceCommand}
                placeholder="e.g., macro normal chest"
                required
              >
              <button 
                type="button" 
                class="btn-test-voice {isTestingVoice ? 'listening' : ''}"
                on:click={testVoiceCommand}
                disabled={isTestingVoice}
              >
                {isTestingVoice ? '🎤' : '🔊'}
              </button>
            </div>
            {#if lastVoiceTest}
              <div class="voice-test-result">{lastVoiceTest}</div>
            {/if}
          </div>
          
          <div class="form-group">
            <label for="category">Category</label>
            <select id="category" bind:value={newMacro.category}>
              {#each categories.slice(1) as category}
                <option value={category}>{category}</option>
              {/each}
            </select>
          </div>
          
          <div class="form-group full-width">
            <label for="content">Macro Content *</label>
            <div class="content-editor">
              <textarea 
                id="content"
                bind:value={newMacro.content}
                placeholder="Enter the text that will be inserted when this macro is used..."
                rows="6"
                required
              ></textarea>
              
              <div class="variable-buttons">
                <span>Quick Variables:</span>
                {#each availableVariables as variable}
                  <button 
                    type="button"
                    class="btn-variable"
                    on:click={() => insertVariable(variable)}
                    title={variable.description}
                  >
                    [{variable.name}]
                  </button>
                {/each}
              </div>
            </div>
          </div>
        </div>
        
        <div class="form-actions">
          <button class="btn btn-secondary" on:click={resetForm}>Cancel</button>
          <button class="btn btn-primary" on:click={saveMacro}>
            {editingMacro ? 'Update Macro' : 'Create Macro'}
          </button>
        </div>
      </div>
    </div>
  {/if}
  
  <div class="macro-list">
    <div class="list-header">
      <span class="macro-count">
        {getFilteredMacros().length} macro{getFilteredMacros().length !== 1 ? 's' : ''}
        {selectedCategory !== 'All' ? `in ${selectedCategory}` : ''}
      </span>
    </div>
    
    <div class="macro-grid">
      {#each getFilteredMacros() as macro}
        <div class="macro-card">
          <div class="macro-card-header">
            <div class="macro-info">
              <h3 class="macro-name">{macro.name}</h3>
              <span class="macro-category">{macro.category}</span>
            </div>
            
            <div class="macro-actions">
              <button 
                class="btn-icon" 
                on:click={() => startEditMacro(macro)}
                title="Edit macro"
              >
                ✏️
              </button>
              
              <button 
                class="btn-icon" 
                on:click={() => duplicateMacro(macro)}
                title="Duplicate macro"
              >
                📋
              </button>
              
              <button 
                class="btn-icon btn-danger" 
                on:click={() => deleteMacro(macro)}
                title="Delete macro"
              >
                🗑️
              </button>
            </div>
          </div>
          
          <div class="voice-command">
            <strong>Voice Command:</strong> "{macro.voiceCommand}"
          </div>
          
          <div class="macro-content">
            <strong>Content:</strong>
            <div class="content-preview">
              {macro.content.length > 150 ? macro.content.substring(0, 150) + '...' : macro.content}
            </div>
          </div>
        </div>
      {/each}
      
      {#if getFilteredMacros().length === 0}
        <div class="empty-state">
          {#if searchTerm || selectedCategory !== 'All'}
            <p>No macros found matching your search criteria.</p>
            <button class="btn btn-secondary" on:click={() => { searchTerm = ''; selectedCategory = 'All'; }}>
              Clear Filters
            </button>
          {:else}
            <p>No macros created yet.</p>
            <button class="btn btn-primary" on:click={startAddMacro}>
              Create Your First Macro
            </button>
          {/if}
        </div>
      {/if}
    </div>
  </div>
</div>

<style>
  .macro-manager {
    padding: 2rem;
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .macro-header {
    text-align: center;
    margin-bottom: 2rem;
  }
  
  .macro-header h1 {
    color: #2c3e50;
    margin-bottom: 0.5rem;
  }
  
  .macro-header p {
    color: #7f8c8d;
    font-size: 1.1rem;
  }
  
  .macro-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
  }
  
  .control-group {
    display: flex;
    gap: 1rem;
    align-items: center;
  }
  
  .btn {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.2s ease;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
  }
  
  .btn-primary {
    background: linear-gradient(135deg, #3498db, #2980b9);
    color: white;
  }
  
  .btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.3);
  }
  
  .btn-secondary {
    background: #ecf0f1;
    color: #2c3e50;
    border: 1px solid #bdc3c7;
  }
  
  .btn-secondary:hover {
    background: #d5dbdb;
  }
  
  .search-input {
    padding: 0.75rem;
    border: 2px solid #ecf0f1;
    border-radius: 8px;
    font-size: 0.9rem;
    min-width: 200px;
  }
  
  .search-input:focus {
    outline: none;
    border-color: #3498db;
  }
  
  .category-select {
    padding: 0.75rem;
    border: 2px solid #ecf0f1;
    border-radius: 8px;
    font-size: 0.9rem;
    background: white;
  }
  
  .macro-form-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
    padding: 2rem;
  }
  
  .macro-form {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    width: 100%;
    max-width: 700px;
    max-height: 90vh;
    overflow-y: auto;
  }
  
  .form-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #ecf0f1;
  }
  
  .form-header h2 {
    margin: 0;
    color: #2c3e50;
  }
  
  .btn-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #7f8c8d;
    padding: 0.25rem;
  }
  
  .btn-close:hover {
    color: #e74c3c;
  }
  
  .form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
    margin-bottom: 2rem;
  }
  
  .form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .form-group.full-width {
    grid-column: 1 / -1;
  }
  
  .form-group label {
    font-weight: 600;
    color: #2c3e50;
  }
  
  .form-group input,
  .form-group select,
  .form-group textarea {
    padding: 0.75rem;
    border: 2px solid #ecf0f1;
    border-radius: 8px;
    font-size: 0.9rem;
    transition: border-color 0.2s ease;
  }
  
  .form-group input:focus,
  .form-group select:focus,
  .form-group textarea:focus {
    outline: none;
    border-color: #3498db;
  }
  
  .voice-input-group {
    display: flex;
    gap: 0.5rem;
  }
  
  .voice-input-group input {
    flex: 1;
  }
  
  .btn-test-voice {
    padding: 0.75rem;
    border: 2px solid #27ae60;
    background: #2ecc71;
    color: white;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
  }
  
  .btn-test-voice:hover:not(:disabled) {
    background: #27ae60;
  }
  
  .btn-test-voice.listening {
    animation: pulse 1.5s infinite;
    background: #e74c3c;
    border-color: #c0392b;
  }
  
  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }
  
  .voice-test-result {
    font-size: 0.8rem;
    padding: 0.5rem;
    border-radius: 4px;
    margin-top: 0.5rem;
  }
  
  .content-editor {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  .variable-buttons {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    align-items: center;
    padding: 1rem;
    background: #f8f9fa;
    border-radius: 8px;
  }
  
  .variable-buttons span {
    font-weight: 600;
    color: #2c3e50;
    margin-right: 0.5rem;
  }
  
  .btn-variable {
    padding: 0.25rem 0.5rem;
    background: #3498db;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 0.8rem;
    transition: background 0.2s ease;
  }
  
  .btn-variable:hover {
    background: #2980b9;
  }
  
  .form-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
    padding-top: 1rem;
    border-top: 2px solid #ecf0f1;
  }
  
  .list-header {
    margin-bottom: 1rem;
  }
  
  .macro-count {
    color: #7f8c8d;
    font-weight: 600;
  }
  
  .macro-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
  }
  
  .macro-card {
    background: white;
    border: 2px solid #ecf0f1;
    border-radius: 12px;
    padding: 1.5rem;
    transition: all 0.2s ease;
  }
  
  .macro-card:hover {
    border-color: #3498db;
    box-shadow: 0 4px 12px rgba(52, 152, 219, 0.1);
  }
  
  .macro-card-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 1rem;
  }
  
  .macro-info {
    flex: 1;
  }
  
  .macro-name {
    margin: 0 0 0.5rem 0;
    color: #2c3e50;
    font-size: 1.1rem;
  }
  
  .macro-category {
    background: #e3f2fd;
    color: #1976d2;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
  }
  
  .macro-actions {
    display: flex;
    gap: 0.5rem;
  }
  
  .btn-icon {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 6px;
    transition: background 0.2s ease;
  }
  
  .btn-icon:hover {
    background: #ecf0f1;
  }
  
  .btn-icon.btn-danger:hover {
    background: #ffebee;
  }
  
  .voice-command {
    margin-bottom: 1rem;
    padding: 0.75rem;
    background: #f8f9fa;
    border-radius: 8px;
    font-size: 0.9rem;
  }
  
  .macro-content {
    font-size: 0.9rem;
  }
  
  .content-preview {
    margin-top: 0.5rem;
    padding: 0.75rem;
    background: #f8f9fa;
    border-radius: 8px;
    color: #5d6d7e;
    line-height: 1.4;
  }
  
  .empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem;
    color: #7f8c8d;
  }
  
  .empty-state p {
    margin-bottom: 1.5rem;
    font-size: 1.1rem;
  }
  
  @media (max-width: 768px) {
    .macro-manager {
      padding: 1rem;
    }
    
    .macro-controls {
      flex-direction: column;
      align-items: stretch;
    }
    
    .control-group {
      justify-content: center;
    }
    
    .form-grid {
      grid-template-columns: 1fr;
    }
    
    .macro-grid {
      grid-template-columns: 1fr;
    }
    
    .search-input {
      min-width: auto;
    }
  }
</style>