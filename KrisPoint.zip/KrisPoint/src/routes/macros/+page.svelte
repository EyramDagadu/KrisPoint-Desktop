<!-- routes/macros/+page.svelte - Macro Management Page -->
<script>
  import MacroManager from '$lib/components/MacroManager.svelte';
  import Layout from '$lib/components/Layout.svelte';
</script>

<svelte:head>
  <title>Voice Macros - KrisPoint</title>
  <meta name="description" content="Manage voice-activated macros for faster radiology reporting">
</svelte:head>

<Layout>
  <div class="macros-page">
    <MacroManager />
  </div>
</Layout>

<style>
  .macros-page {
    min-height: 100vh;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  }
  
  @media (max-width: 768px) {
    .macros-page {
      padding: 0;
    }
  }
</style>