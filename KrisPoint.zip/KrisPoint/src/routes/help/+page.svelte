<script>
  import Layout from '$lib/components/Layout.svelte';
  import Header from '$lib/components/ui/Header.svelte';
</script>

<Layout>
  <Header title="Patient Management" />
  <div class="page-content">
    <h2>Patient List</h2>
    <p>Patient management functionality coming soon...</p>
  </div>
</Layout>

<style>
  .page-content {
    padding: 2rem;
    background: white;
    border-radius: 0.75rem;
  }
</style>