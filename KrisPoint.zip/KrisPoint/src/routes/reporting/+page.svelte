<!-- src/routes/reporting/+page.svelte -->
<script>
  import Layout from '$lib/components/Layout.svelte';
  import ReportWorkspace from '$lib/components/reporting/ReportWorkspace.svelte';
  import { patientData, reportActions, uiActions, hasCompletePatientData } from '$lib/stores/reportStore.js';
  import { onMount } from 'svelte';
  import { browser } from '$app/environment';
  import { page } from '$app/stores';
  
  let sidebarCollapsed = false;
  let isInitialized = false;
  
  // Check URL parameters for new report intent
  $: isNewReport = $page.url.searchParams.has('new');
  
  onMount(() => {
    if (!browser) return;
    
    // Load any existing report from storage
    const savedReport = reportActions.loadFromStorage();
    
    // If URL has ?new parameter, force new report flow
    if (isNewReport) {
      reportActions.clearReport();
      uiActions.showPatientModal();
    } else if (!$hasCompletePatientData) {
      // No complete patient data and not explicitly new - show modal
      uiActions.showPatientModal();
    }
    
    isInitialized = true;
  });
  
  function handleNewReport() {
    if (!browser) return;
    reportActions.clearReport();
    uiActions.showPatientModal();
  }
  
  function toggleSidebar() {
    if (!browser) return;
    sidebarCollapsed = !sidebarCollapsed;
  }
</script>

<svelte:head>
  <title>Radiology Reporting - KrisPoint</title>
</svelte:head>

{#if browser && isInitialized}
  <Layout 
    pageTitle="Radiology Reporting" 
    showNewReportButton={true}
    {sidebarCollapsed}
    on:newReport={handleNewReport}
    on:toggleSidebar={toggleSidebar}
  >
    <div class="reporting-container">
      <ReportWorkspace />
    </div>
  </Layout>
{:else}
  <div class="loading-container">
    <div class="loading-spinner"></div>
    <p>Loading reporting interface...</p>
  </div>
{/if}

<style>
  .reporting-container {
    height: 100%;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    /* Remove gap and padding to let ReportWorkspace control layout */
  }
  
  /* Ensure ReportWorkspace gets full available space */
  :global(.reporting-container .report-workspace) {
    height: 100%;
    border-radius: 0; /* Remove border radius since it's in layout */
    box-shadow: none; /* Remove shadow since layout handles it */
  }
  
  .loading-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100vh;
    gap: 1rem;
    background: #f8fafc;
  }
  
  .loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #e5e7eb;
    border-top: 3px solid #3b82f6;
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
  
  .loading-container p {
    font-size: 1.125rem;
    color: #6b7280;
    margin: 0;
  }
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
</style>