<!-- src/routes/templates/+page.svelte -->
<script>
  import Layout from '$lib/components/Layout.svelte';
  
  let sidebarCollapsed = false;
  
  function toggleSidebar() {
    sidebarCollapsed = !sidebarCollapsed;
  }
  
  // Sample template data
  const templateCategories = [
    {
      name: 'CT Templates',
      templates: [
        { id: 1, name: 'CT Head', description: 'Standard head CT template' },
        { id: 2, name: 'CT Chest', description: 'Chest CT with contrast template' },
        { id: 3, name: 'CT Abdomen/Pelvis', description: 'Abdominal CT template' },
      ]
    },
    {
      name: 'MRI Templates',
      templates: [
        { id: 4, name: 'MRI Brain', description: 'Brain MRI template' },
        { id: 5, name: 'MRI Spine', description: 'Spine MRI template' },
        { id: 6, name: 'MRI MSK', description: 'Musculoskeletal MRI template' },
      ]
    },
    {
      name: 'X-Ray Templates',
      templates: [
        { id: 7, name: 'Chest X-Ray', description: 'Standard chest radiograph template' },
        { id: 8, name: 'Abdominal X-Ray', description: 'Abdominal radiograph template' },
      ]
    }
  ];
  
  function editTemplate(template) {
    console.log('Edit template:', template.name);
    // Navigate to template editor
  }
  
  function createTemplate() {
    console.log('Create new template');
    // Open template creation modal
  }
</script>

<svelte:head>
  <title>Report Templates - KrisPoint</title>
</svelte:head>

<Layout 
  pageTitle="Report Templates" 
  {sidebarCollapsed}
  on:toggleSidebar={toggleSidebar}
>
  <div class="templates-page">
    <div class="page-header">
      <h1>Report Templates</h1>
      <p>Manage your radiology report templates for faster reporting</p>
      <button class="btn btn-primary" on:click={createTemplate}>
        <span>+</span>
        Create New Template
      </button>
    </div>
    
    <div class="templates-grid">
      {#each templateCategories as category}
        <div class="template-category">
          <h2>{category.name}</h2>
          <div class="templates-list">
            {#each category.templates as template}
              <div class="template-card">
                <div class="template-info">
                  <h3>{template.name}</h3>
                  <p>{template.description}</p>
                </div>
                <div class="template-actions">
                  <button class="btn btn-outline" on:click={() => editTemplate(template)}>
                    Edit
                  </button>
                  <button class="btn btn-secondary">
                    Use Template
                  </button>
                </div>
              </div>
            {/each}
          </div>
        </div>
      {/each}
    </div>
  </div>
</Layout>

<style>
  .templates-page {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .page-header {
    margin-bottom: 2rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .page-header h1 {
    margin: 0;
    color: #1f2937;
  }
  
  .page-header p {
    color: #6b7280;
    margin: 0;
  }
  
  .btn {
    padding: 0.5rem 1rem;
    border-radius: 0.375rem;
    border: none;
    font-weight: 500;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s;
    align-self: flex-start;
    margin-top: 1rem;
  }
  
  .btn-primary {
    background: #2563eb;
    color: white;
  }
  
  .btn-primary:hover {
    background: #1d4ed8;
  }
  
  .btn-outline {
    background: white;
    color: #374151;
    border: 1px solid #d1d5db;
  }
  
  .btn-outline:hover {
    background: #f9fafb;
  }
  
  .btn-secondary {
    background: #6b7280;
    color: white;
  }
  
  .btn-secondary:hover {
    background: #4b5563;
  }
  
  .templates-grid {
    display: flex;
    flex-direction: column;
    gap: 2rem;
  }
  
  .template-category h2 {
    margin: 0 0 1rem 0;
    color: #374151;
    font-size: 1.25rem;
  }
  
  .templates-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1rem;
  }
  
  .template-card {
    background: white;
    padding: 1.5rem;
    border-radius: 0.75rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  .template-info h3 {
    margin: 0 0 0.5rem 0;
    color: #1f2937;
  }
  
  .template-info p {
    margin: 0;
    color: #6b7280;
    font-size: 0.875rem;
  }
  
  .template-actions {
    display: flex;
    gap: 0.5rem;
    margin-top: auto;
  }
  
  @media (max-width: 768px) {
    .templates-list {
      grid-template-columns: 1fr;
    }
    
    .template-actions {
      flex-direction: column;
    }
  }
</style>