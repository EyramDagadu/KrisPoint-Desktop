<!-- src/routes/+page.svelte - Fixed Dashboard -->
<script>
  import Layout from '$lib/components/Layout.svelte';
  import { goto } from '$app/navigation';
  
  let sidebarCollapsed = false;
  
  function createNewReport() {
    // Navigate to reporting page with new report parameter
    goto('/reporting?new=true');
  }
  
  function continueReport(reportId) {
    // Navigate to reporting page to continue existing report
    goto(`/reporting?continue=${reportId}`);
  }
  
  function toggleSidebar() {
    sidebarCollapsed = !sidebarCollapsed;
  }
  
  // Mock data for recent reports
  const recentReports = [
    { 
      id: 1, 
      patient: 'John Doe', 
      study: 'CT Chest', 
      date: '2024-01-15',
      status: 'Draft' 
    },
    { 
      id: 2, 
      patient: 'Jane Smith', 
      study: 'MRI Brain', 
      date: '2024-01-14',
      status: 'Final' 
    },
    { 
      id: 3, 
      patient: 'Robert Johnson', 
      study: 'X-Ray Abdomen', 
      date: '2024-01-14',
      status: 'Pending Review' 
    }
  ];
</script>

<Layout 
  pageTitle="KrisPoint Dashboard" 
  showNewReportButton={true}
  {sidebarCollapsed}
  on:newReport={createNewReport}
  on:toggleSidebar={toggleSidebar}
>
  <div class="dashboard">
    <div class="welcome-section">
      <h1>Welcome to KrisPoint</h1>
      <p>Your AI-powered radiology reporting assistant</p>
      
      <div class="quick-actions">
        <button class="action-card primary" on:click={createNewReport}>
          <div class="action-icon">📝</div>
          <div class="action-content">
            <h3>New Report</h3>
            <p>Start dictating a new radiology report</p>
          </div>
        </button>
        
        <a href="/reporting" class="action-card">
          <div class="action-icon">⚡</div>
          <div class="action-content">
            <h3>Continue Reporting</h3>
            <p>Resume your current report</p>
          </div>
        </a>
        
        <a href="/reports" class="action-card">
          <div class="action-icon">📊</div>
          <div class="action-content">
            <h3>View Reports</h3>
            <p>Browse your completed reports</p>
          </div>
        </a>
        
        <a href="/templates" class="action-card">
          <div class="action-icon">📋</div>
          <div class="action-content">
            <h3>Templates</h3>
            <p>Manage report templates</p>
          </div>
        </a>
      </div>
    </div>
    
    <div class="recent-section">
      <div class="section-header">
        <h2>Recent Reports</h2>
        <a href="/reports" class="view-all-link">View all reports</a>
      </div>
      <div class="reports-list">
        {#each recentReports as report}
          <div class="report-card" class:clickable={report.status === 'Draft'}>
            <div class="report-info">
              <h4>{report.patient}</h4>
              <p class="study-info">{report.study}</p>
              <p class="date-info">{report.date}</p>
            </div>
            <div class="report-actions">
              <div class="report-status">
                <span class="status {report.status.toLowerCase().replace(' ', '-')}">{report.status}</span>
              </div>
              {#if report.status === 'Draft'}
                <button 
                  class="continue-btn" 
                  on:click={() => continueReport(report.id)}
                  title="Continue this report"
                >
                  Continue
                </button>
              {/if}
            </div>
          </div>
        {/each}
      </div>
    </div>
    
    <!-- Quick Stats Section -->
    <div class="stats-section">
      <div class="stat-card">
        <div class="stat-number">23</div>
        <div class="stat-label">Reports This Week</div>
      </div>
      <div class="stat-card">
        <div class="stat-number">2</div>
        <div class="stat-label">Pending Review</div>
      </div>
      <div class="stat-card">
        <div class="stat-number">156</div>
        <div class="stat-label">Total Reports</div>
      </div>
    </div>
  </div>
</Layout>

<style>
  .dashboard {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1.5rem;
  }
  
  .welcome-section {
    margin-bottom: 3rem;
  }
  
  .welcome-section h1 {
    margin: 0 0 0.5rem 0;
    color: #1f2937;
    font-size: 2.25rem;
    font-weight: 700;
  }
  
  .welcome-section p {
    color: #6b7280;
    font-size: 1.125rem;
    margin-bottom: 2rem;
  }
  
  .quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
  }
  
  .action-card {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1.5rem;
    background: white;
    border-radius: 0.75rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    text-decoration: none;
    color: inherit;
    cursor: pointer;
    border: none;
    transition: all 0.2s ease-in-out;
    width: 100%;
    text-align: left;
  }
  
  .action-card:hover {
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    transform: translateY(-2px);
  }
  
  .action-card.primary {
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3);
  }
  
  .action-card.primary:hover {
    box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
  }
  
  .action-icon {
    font-size: 2rem;
    opacity: 0.9;
    flex-shrink: 0;
  }
  
  .action-content h3 {
    margin: 0 0 0.25rem 0;
    font-size: 1.125rem;
    font-weight: 600;
  }
  
  .action-content p {
    margin: 0;
    font-size: 0.875rem;
    opacity: 0.8;
  }
  
  .recent-section {
    margin-bottom: 3rem;
  }
  
  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
  }
  
  .recent-section h2 {
    margin: 0;
    color: #1f2937;
    font-size: 1.5rem;
    font-weight: 600;
  }
  
  .view-all-link {
    color: #3b82f6;
    text-decoration: none;
    font-weight: 500;
    font-size: 0.875rem;
  }
  
  .view-all-link:hover {
    color: #2563eb;
    text-decoration: underline;
  }
  
  .reports-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }
  
  .report-card {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.25rem;
    background: white;
    border-radius: 0.75rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease-in-out;
  }
  
  .report-card.clickable:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transform: translateY(-1px);
  }
  
  .report-info h4 {
    margin: 0 0 0.25rem 0;
    color: #1f2937;
    font-weight: 600;
  }
  
  .study-info {
    margin: 0 0 0.25rem 0;
    font-size: 0.875rem;
    color: #374151;
    font-weight: 500;
  }
  
  .date-info {
    margin: 0;
    font-size: 0.75rem;
    color: #6b7280;
  }
  
  .report-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
  }
  
  .status {
    padding: 0.375rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.025em;
  }
  
  .status.draft {
    background: #fef3c7;
    color: #92400e;
  }
  
  .status.final {
    background: #d1fae5;
    color: #065f46;
  }
  
  .status.pending-review {
    background: #fde68a;
    color: #92400e;
  }
  
  .continue-btn {
    padding: 0.5rem 1rem;
    background: #3b82f6;
    color: white;
    border: none;
    border-radius: 0.375rem;
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.2s;
  }
  
  .continue-btn:hover {
    background: #2563eb;
  }
  
  .stats-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
  }
  
  .stat-card {
    background: white;
    padding: 2rem;
    border-radius: 0.75rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    text-align: center;
  }
  
  .stat-number {
    font-size: 2.5rem;
    font-weight: 700;
    color: #3b82f6;
    margin-bottom: 0.5rem;
  }
  
  .stat-label {
    color: #6b7280;
    font-size: 0.875rem;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }
  
  @media (max-width: 768px) {
    .dashboard {
      padding: 1rem;
    }
    
    .welcome-section h1 {
      font-size: 2rem;
    }
    
    .quick-actions {
      grid-template-columns: 1fr;
    }
    
    .action-card {
      padding: 1rem;
    }
    
    .section-header {
      flex-direction: column;
      align-items: flex-start;
      gap: 0.5rem;
    }
    
    .report-card {
      flex-direction: column;
      align-items: flex-start;
      gap: 1rem;
    }
    
    .report-actions {
      align-self: stretch;
      justify-content: space-between;
    }
  }
</style>